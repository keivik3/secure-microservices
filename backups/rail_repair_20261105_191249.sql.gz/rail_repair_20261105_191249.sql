--
-- PostgreSQL database dump
--

\restrict 4pY9YPK28FepZefxEqUfDB8OUFw8bOK60ooEGw5kpvLNAxURwL3j58oAKZFOhiv

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: tickets; Type: TABLE; Schema: public; Owner: app
--

CREATE TABLE public.tickets (
    id bigint NOT NULL,
    track_section text NOT NULL,
    defect_type text NOT NULL,
    description text NOT NULL,
    priority text NOT NULL,
    status text DEFAULT 'NEW'::text NOT NULL,
    reporter text NOT NULL,
    crew text DEFAULT ''::text NOT NULL,
    planned_date text DEFAULT ''::text NOT NULL,
    comment text DEFAULT ''::text NOT NULL,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


ALTER TABLE public.tickets OWNER TO app;

--
-- Name: tickets_id_seq; Type: SEQUENCE; Schema: public; Owner: app
--

CREATE SEQUENCE public.tickets_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tickets_id_seq OWNER TO app;

--
-- Name: tickets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: app
--

ALTER SEQUENCE public.tickets_id_seq OWNED BY public.tickets.id;


--
-- Name: tickets id; Type: DEFAULT; Schema: public; Owner: app
--

ALTER TABLE ONLY public.tickets ALTER COLUMN id SET DEFAULT nextval('public.tickets_id_seq'::regclass);


--
-- Data for Name: tickets; Type: TABLE DATA; Schema: public; Owner: app
--

COPY public.tickets (id, track_section, defect_type, description, priority, status, reporter, crew, planned_date, comment, created_at, updated_at) FROM stdin;
\.


--
-- Name: tickets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: app
--

SELECT pg_catalog.setval('public.tickets_id_seq', 1, false);


--
-- Name: tickets tickets_pkey; Type: CONSTRAINT; Schema: public; Owner: app
--

ALTER TABLE ONLY public.tickets
    ADD CONSTRAINT tickets_pkey PRIMARY KEY (id);


--
-- Name: idx_tickets_priority; Type: INDEX; Schema: public; Owner: app
--

CREATE INDEX idx_tickets_priority ON public.tickets USING btree (priority);


--
-- Name: idx_tickets_status; Type: INDEX; Schema: public; Owner: app
--

CREATE INDEX idx_tickets_status ON public.tickets USING btree (status);


--
-- PostgreSQL database dump complete
--

\unrestrict 4pY9YPK28FepZefxEqUfDB8OUFw8bOK60ooEGw5kpvLNAxURwL3j58oAKZFOhiv

